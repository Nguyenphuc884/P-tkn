from flask import Flask, request, jsonify
from datetime import datetime
import random

app = Flask(__name__)

@app.route('/api/follow')
def follow():
    username = request.args.get("user")
    if not username:
        return jsonify({"success": False, "error": "Thiếu user!"})
    
    response = {
        "success": True,
        "username": username,
        "added": random.randint(100, 1000),
        "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    return jsonify(response)

if __name__ == '__main__':
    app.run()
